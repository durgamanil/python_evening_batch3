# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 18:45:32 2022

@author: durga
"""

# =============================================================================
# different ways of print
# =============================================================================

print("this is testing")

a =100
b =200
print("a =",a)
print("b =",b)

print("a=",a,"b=",b)


# =============================================================================
# format string
# =============================================================================
a =100
b =200
#formatstring --->F,f

print(f"a= {a}")
print(f"b= {b}")
print(F"a= {a}")
print(F"b= {b}")

print(f'a= {a}')
print(f'b= {b}')

print(f'a= {a} b = {b} ')
#print(f'b= {b}')


test ="this is testing"
print(test.format(a =10,b=20))


print("this is testing {a} {b}".format(a =10,b=20))


print(" this is {name} and my age {age}".format(name ="anil", age = 32))



#print "" -------->python 2.x

#print("this is testing"%format(a,b))
#print("this is testing {a, b} "%a,%b))



# =============================================================================
# coding styles
# =============================================================================

1.camel coding
2.snake coding
3.pascal coding


1.camel coding
ThisIsTesting
HelloWorld
MyFriend


2.snake coding
this_is_testing
hello_world
my_friend

3.pascal coding
Thisistesting
Helloworld
Myfriend


test1 = 10
argument1 = 10
argument_in_function1 = 10
veera_venkata_satya_narayana_vara_prasad = 10
print(veera_venkata_satya_narayana_vara_prasad)

my_mapping_file_trigger_element5 = 100
my_mpg_fl_tr_ele5 = 100


# =============================================================================
# Boolean data type
# =============================================================================

Bool datatype
1.True ===>1
2.False ===>0


a =10
print(a==10)

'==' comparison operators

a =10
print(a != 10)


# =============================================================================
# complex
# =============================================================================

ai+bj
5+6j


a = complex(1)
print(a)
b = complex(5,6)
print(b)
print(type(b))

5.6+7.3j

a = complex(1.4)
print(a)
b = complex(5.6,7.3)
print(b)
print(type(b))






















