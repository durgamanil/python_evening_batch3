# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 19:00:48 2022

@author: durga
"""

# print("this is my first python code")

# print("this is my first python code")
# print("this is my first python code")
# print("this is my first python code")
# print("this is my first python code")
# print("this is my first python code")
# print("this is my first python code")
# print("this is my first python code")
# print("this is my first python code")


# print("Python was conceived in the late 1980s[38] \
#       by Guido van Rossum at Centrum Wiskunde & Informatica (CWI) \
#    in the Netherlands as a successor to the ABC programming language,\
#        which was inspired by SETL,[39] capable of exception handling \
#         and interfacing with the Amoeba operating system.\
#        [10] Its implementation began in December 1989.[40]\
#         Van Rossum shouldered sole responsibility for the project,\
#     as the lead developer, until 12 July 2018, \
#         when he announced his 'permanent vacation' \
#         from his responsibilities as Python's 'benevolent dictator for life', \
#         a title the Python community bestowed upon him to reflect his long-term \
#             commitment as the project's chief decision-maker.[41] In January 2019,\
#                 active Python core developers elected a five-member\
#                     Steering Council to lead the project.[42][43]")
                    
                    
                    
# print(10)#10
# print(20+30)#50

# print(15*15)#225
# print(10*30*15)#4500

#print(((10-3)+(5*4))-1)#

"""
BODMAS
brackets
of
Division
Multiplication
addition
substraction
"""
'''
numbers ----integers
example: 10,20,300,40000


float-------floating numbers 
example:10.5,3.56,6.789,756.34343434

strings-----""double quotes
''----single quotes

bool type----True and False
'''

# a = 10

# print(a)

# b = 20

# print(b)


# print(type(a))
# print(type(b))

'''
output:
    
<class 'int'>
<class 'int'>
'''

# a = 10000000000000000000000000000000000000000000000000000000000000
# print(a)
# print(type(a))


# print(id(a))#1840651190512
# print(id(b))#1840487951248


# nani = 10
# naveen = 10
# print(nani)
# print(naveen)

# print(type(nani))
# print(type(naveen))

# print(id(nani))
# print(id(naveen))
# #
# 1840487950928
# 1840487950928

nani = 10
naveen = 20
print(nani)
print(naveen)

print(type(nani))
print(type(naveen))

print(id(nani))
print(id(naveen))

10
20
<class 'int'>
<class 'int'>
1840487950928
1840487951248















