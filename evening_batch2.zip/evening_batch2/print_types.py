# -*- coding: utf-8 -*-
"""
Created on Thu Apr 14 08:17:03 2022

@author: durga
"""

print(1)

print("mohan")
print('mohan')

print(15.89)


print(45454545454545454547854145478784514245878455878)

print("jdskfjdskfjkdsjfkjdsfkjsdfksdthikiasjkfdsjfkdsjkfstihjfikdshjfkdsjfkjdskfjdslkfjdsfjksdjfkdsjthikhjk")

a =1
b =2
c =3

print(a,b,c)

#
a =1
b =2
c =3

print("a=",a,"b=",b,"c=",c)



a =1
b =2
c =3

print("my variables",a,b,c)

#format


a =1
b =2
c =3

print("my variablesa={},b={},c={}",a,b,c)

print("my variablesa={},b={},c={}".format(a,b,c))
print("my variablesa={},b={},c={}".format(b,a,c))

print("my variables\n a={}, b={},c={}".format(b,a,c))

'''
"\n"---> new line
"\t"---> tab space
"\r"---> carrier return
'''


print("Hello\tmounika\tnaveen\tmohan")
print("Hello\tmounika\nnaveen\tmohan")
print("Hello\nmounika\nnaveen\nmohan")

print("Hello\rworld")
print("H\relloworld")
print("Helloworl\rd")




