# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 18:52:44 2022

@author: durga
"""

if 


if else:
    
    
    
if elif else:
    
    
    
#nesting
a =10
b = 9
c = 4
if a ==10:
    if b ==9:
        if c ==4:
            print("this is nesting")


        
            
if a == 10:
    if b ==5:
        print(b)
    else:
        print(b)
else:
    if b ==4:
        print(b)
    else:
        print(b)
    