


#this addition operation related
def vandana_fun():
    ''' 
    function written by: vandana
    
    date: 24-03-2022
    use of the function: addtion
    
    this is the docstring'''
    
    print("this is the code of vandana")
    

#this substraction operation related
def meghana_fun():
    """ 
    function written by: Meghana
    
    date: 24-03-2022
    use of the function: addtion
    
    this is the docstring"""
    
    print("this is the code of meghana")
    
vandana_fun()
meghana_fun()

vandana_fun.__doc__
meghana_fun.__doc__
