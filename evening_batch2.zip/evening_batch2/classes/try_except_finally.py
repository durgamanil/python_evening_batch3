

try
except:
else:
finally


try:
except:
finally


if else:
if condition:
	"condition is true this block will execute"
else:
	"condition is flase.. then this block will execute


syntax1:

try:
	"connection code"
except:
	"failed contion code"
finally:
	"close connection code"
    
syntax2:   
try:
except:
else:
finally:


example 1:

try:
	"1/0"
except:
	"failed condtion"


