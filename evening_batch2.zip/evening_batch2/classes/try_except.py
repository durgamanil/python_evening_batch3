how to create virtual environment for django project

1. pip install virtualenv
2.mkdir first_project
3.virtualenv -p python3 venv
4.   .\venv\Scripts\activate
5.cd .\venv\
