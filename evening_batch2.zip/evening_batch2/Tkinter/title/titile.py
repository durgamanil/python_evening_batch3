# =============================================================================
# Menubutton
# =============================================================================

from tkinter import *

import tkinter as tk

window = Tk()
window.title("school management")
menu1 = Menubutton(window, text=)

window.mainloop()