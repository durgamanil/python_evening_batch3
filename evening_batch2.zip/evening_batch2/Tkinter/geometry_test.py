# -*- coding: utf-8 -*-
"""
Created on Mon May 30 20:00:57 2022

@author: durga
"""

from tkinter import *

import tkinter as tk

window = Tk()

#tk.Label(window, text="School management system",font=("Times", "50", "bold italic")).grid(column=0, row=2)
window.geometry("600x800")


window.mainloop()


#example2

from tkinter import *

import tkinter as tk

window = Tk()

#tk.Label(window, text="School management system",font=("Times", "50", "bold italic")).grid(column=0, row=2)
window.geometry("1080x800")


window.mainloop()


#

from tkinter import *

import tkinter as tk

window = Tk()
root = Tk()

#tk.Label(window, text="School management system",font=("Times", "50", "bold italic")).grid(column=0, row=2)
window.geometry("1080x800")
root.geometry("100x200")


window.mainloop()
root.mainloop()



