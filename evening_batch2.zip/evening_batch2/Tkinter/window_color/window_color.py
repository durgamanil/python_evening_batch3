# -*- coding: utf-8 -*-
"""
Created on Fri Jun  3 20:04:33 2022

@author: durga
"""

from tkinter import *

import tkinter as tk


window = Tk()
window.geometry("600x800")
window.title("school management")

window.config(bg="pink")

window.mainloop()




# =============================================================================
# 
# =============================================================================

from tkinter import *

import tkinter as tk


window = Tk()
window.geometry("600x800")
window.title("school management")

window["background"]= "red"

window.mainloop()


# =============================================================================
# giving with hex code
# =============================================================================


from tkinter import *

import tkinter as tk


window = Tk()
window.geometry("600x800")
window.title("school management")

window["background"]= "#ff00ff"

window.mainloop()









