# -*- coding: utf-8 -*-
"""
Created on Sat Jun 11 11:30:59 2022

@author: durga
"""

#admission number
#gender
#email id
#father name
#mother name
#DOB
#standard/class
#contact number
#Date of admission
#section
#address