# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 08:06:16 2022

@author: durga
"""

# =============================================================================
# membership operator
# =============================================================================

#in operator


list1 = ["sachin","sewag","kohli"]
print("sachin" in list1)

list2 =["rose","lilli","jasmin"]
print("califlower" in list2)



list3 = [1,2,3,4,5]
print(5 in list3)

list4 = [1,2,3,4,5]
print(6 in list3)



#not in 

list2 =["banana","apple","jackfroot","orange"]
print("lemon" not in list2) #True
print("banana" not in list2) # False


list3 =[1,2,3,4,5]
print(7 not in list3)#True
print(4 not in list3)#False






