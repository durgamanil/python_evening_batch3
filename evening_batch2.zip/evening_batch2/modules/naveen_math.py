# -*- coding: utf-8 -*-
"""
Created on Thu Apr 28 19:42:35 2022

@author: durga
"""

def addition_fn(a,b):
    print(a+b)
    
    
def sub_fn(a,b):
    print(a-b)
    
    
    
def division_fn(a,b):
    print(a/b)
    
    
def power_fn(a,b):
    print(a**b)
    
def addition_substraction_division_power(a,b):
    print(a+b)
    print(a-b)
    print(a/b)
    print(a**b)
    
def network_connection_ip_fetch_give_mac_address_connectivity_check():
    print("network checking")