# -*- coding: utf-8 -*-
"""
Created on Thu Apr 28 19:34:22 2022

@author: durga
"""

# from anil_math import addition_fn,sub_fn as add , sub


# add(20,30)
# sub(30,20)



# =============================================================================
# 
# =============================================================================
import anil_math as am
import naveen_math
import sohan_math


#dir(anil_math)

am.addition_fn(10, 20)
# anil_math.sub_fn(a, b)
# anil_math.network_connection_ip_fetch_give_mac_address_connectivity_check()

