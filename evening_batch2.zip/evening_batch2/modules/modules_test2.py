# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 19:32:04 2022

@author: durga
"""
#from anil_math import addition_fn 
#from anil_math import addition_fn as add_fn
#from anil_math import sub_fn
# from anil_math import addition_substraction_division_power
# from anil_math import addition_substraction_division_power as asdp
# from anil_math import network_connection_ip_fetch_give_mac_address_connectivity_check
# from anil_math import network_connection_ip_fetch_give_mac_address_connectivity_check as amit
# #import pandas as pd

# from anil_math import addition_fn as add
# from anil_math import sub_fn as sub

from anil_math import addition_fn,sub_fn as add , sub


#
#import anil_math

#add_fn(20,30)
# sub_fn(100000000000,1)
# division_fn(10, 2)
# power_fn(5, 2)

#addition_substraction_division_power(20, 10)

#asdp(20, 10)


# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()
# network_connection_ip_fetch_give_mac_address_connectivity_check()

#ntr()

add(20,30)
sub(30,20)