# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 19:12:20 2022

@author: durga
"""
#import function_test from func1
from function_test import func1
from function_test import func2
from function_test import func3

import os
import time






#os.listdir()
func1()
time.sleep(10)
func2()
time.sleep(10)
func3()


