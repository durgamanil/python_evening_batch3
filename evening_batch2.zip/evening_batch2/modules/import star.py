# -*- coding: utf-8 -*-
"""
Created on Wed May  4 19:01:25 2022

@author: durga
"""
from sohan_math import *

#from sohan_math import addition_fn,sub_fn,division_fn


addition_fn(10,20)
sub_fn(10, 20)
division_fn(30, 3)





