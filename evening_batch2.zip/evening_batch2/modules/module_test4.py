# -*- coding: utf-8 -*-
"""
Created on Sat Apr 30 19:15:25 2022

@author: durga
"""

import time
import os
import datetime

import sys
import math



x = datetime.datetime.now()
print(x)

time.sleep(5)

for i in range(0,100):
    print(i)
    #time.sleep(5)



x = datetime.datetime.now()
print(x)



print(sys.path)

print(sys.modules)

print(math.pi)

print(22/7)

print(math.sqrt(64))

print(int(math.tan(45)))

print(math.tan(90))

#print(1/0)




