# -*- coding: utf-8 -*-
"""
Created on Sat Apr 30 19:02:16 2022

@author: durga
"""


# import sohan_math as sm




# sm.addition_fn(10, 300000)

# a =sm.dict1["name"]
# print(a)


import naveen_math
import anil_math
from sohan_math import dict1

a =dict1["name"]
print(a)