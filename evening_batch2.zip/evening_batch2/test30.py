# -*- coding: utf-8 -*-
"""
Created on Thu Mar 10 18:45:50 2022

@author: durga
"""
a = 10
print("hello katraju",a)
print("NTR")

tickets = 2

if tickets ==2:
    print("watch movie")
else:
    print("went to park")