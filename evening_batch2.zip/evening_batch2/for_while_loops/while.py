# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 19:05:18 2022

@author: durga
"""

# =============================================================================
# while is unstoppable loop
# =============================================================================


syntax:
    while condition:
        statements
        
        

a = 1
    
while a <= 5:
    print(a)
    a = a+1



print("outside")




a =10

while a <= 20:
    print(a)
    a = a+1



a =100

while a >= 20:
    print(a)
    a = a+1





#interview

a =100

while a <20:
    print(a)
    a = a+1
    
 
    
 
a =100

while 1:
    print(a)
    a = a+1




a =100
while True:
    print(a)
    a = a+1
    

# =============================================================================
# 
# =============================================================================



a =100

while (((6<a and a >8) or a<36) or (a<=34 and a<12)):
    print(a)



# =============================================================================
# 
# =============================================================================

a =0

while 0==0:
    print(a)
    

    


a =0

while 0:
    print(a)
    
    
print("outside")
    




a =0

while 100:
    print(a)
    
    
print("outside")



a =0

while 1004544545456456454564564545432134545132134654:
    print(a)
    
    
print("outside")

