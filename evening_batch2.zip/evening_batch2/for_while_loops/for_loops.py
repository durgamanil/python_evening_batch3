# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 19:20:18 2022

@author: durga
"""

# =============================================================================
# loop control
# =============================================================================

1.For -----> condition based  excutes number of times
2.While-----> unstoppable loop

range()-----> in built function

it takes 3 arguemnts
range(start,stop,step)


syntax:
    for i in range(0,5,1):
        print("testing")



for i in range(0,5,1):
    print("testing")
    
    
for i in range(0,9,1):
    print("testing",i)
    



for i in range(0,20,2):
    print("testing",i)
    
    
for i in range(0,21,2):
    print("testing",i)
    
    
    
for i in range(0,21,3):
    print("testing",i)
    
    
for i in range(1,21,3):
    print("testing",i)



for i in range(1,21,4):
    print("testing",i)
    
    
for i in range(1,100,10):
    print("testing",i)
    
    
for i in range(1,100):
    print("testing",i)
    
    
    
for i in range(100):
    print("testing",i)
    
    
for i in range(1,):
    print("testing",i)
    
    
for i in range(10,0,-1):
    print("testing",i)
    
for i in range(10,0,-2):
    print("testing",i)
    
for i in range( 100, 0,-20):
    print("testing",i)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    