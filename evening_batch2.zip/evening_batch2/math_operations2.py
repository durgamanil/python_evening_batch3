# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 19:31:43 2022

@author: durga
"""

a = int(input("enter your number"))

if a%2 ==0:
    print("even number",a)
else:
    print("not a even number")