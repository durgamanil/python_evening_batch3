# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 08:45:44 2022

@author: durga
"""

print("Hello \r world")

print("thisis the text for testing \r1234")


print("thisis the text for testing \r1234,561,213")


print("this is testing\ranildkjdfkgjkdfjgkjdfkgjkdfjgkdfjsgkjds")
