# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 08:55:59 2022

@author: durga
"""

def manoj_fn():
    print("this is inside manoj fun")
    print(30+40)
    print(10+20)



if __name__ == '__main__':  #main function
    #print(50+40)
    print("iam in main funtion")
    print("function testing is going on ")
    manoj_fn()   #this is the function call
    print("="*30)
    print("this is after function call")
    
    