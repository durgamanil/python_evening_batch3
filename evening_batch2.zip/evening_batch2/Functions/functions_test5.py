# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 09:09:54 2022

@author: durga
"""


#defination of the addition function
# def addition_fn():
#     print(10+20)
   



# if __name__ == '__main__':  #main function
#     #a = input("enter your first number")
#     #b = input("enter your second number")
#     for  i in range(0,10,1):
#         addition_fn()   #this is the function call
#         #a, b are arguments
        
        
        
# def addition_fn():
#     print(10+20)
   

# if __name__ == '__main__':  #main function
#     #a = input("enter your first number")
#     #b = input("enter your second number")
#     for  i in range(0,10,1):
#         addition_fn(a,b)   #this is the function call
#         #a, b are arguments
        
        



# def addition_fn(a,b):
#     #print(10+20)
#     print("this is testing")
#     print(a+b)
   

# if __name__ == '__main__':  #main function
#     #a = input("enter your first number")
#     #b = input("enter your second number")
#     #for  i in range(0,10,1):
#     addition_fn(10,20)   #this is the function call
#     #a, b are arguments
    
    
    

# def addition_fn(a,b):
#     print(a+b)
   

# if __name__ == '__main__':  #main function
#     #a = input("enter your first number")
#     #b = input("enter your second number")
#     for  i in range(0,10,1):
#         addition_fn(50,70)   #this is the function call
#         #a, b are arguments
        
        


# def addition_fn(a1,b1):
#     print(a1+b1)
   

# if __name__ == '__main__':  #main function
#     a = int(input("enter your first number"))
#     b = int(input("enter your second number"))
#     for  i in range(0,10,1):
#         addition_fn(a,b)   #this is the function call
#         #a, b are arguments
                
 
        
 
    
# def addition_fn(a1,b1):
#     print(a1+b1)
   

# if __name__ == '__main__':  #main function
#     a = int(input("enter your first number"))
#     b = int(input("enter your second number"))
#     addition_fn(a,b)   #this is the function call
#         #a, b are arguments

        
def addition_fn(a1,b1):
    print(a1+b1)
   
# a = int(input("enter your first number"))
# b = int(input("enter your second number"))                
# addition_fn(a,b)   


def addition_fn2(a1,b1,c1):
    print(a1+b1+c1)  
    
# a = int(input("enter your first number"))
# b = int(input("enter your second number"))
# c = int(input("enter your third number"))

#addition_fn2(a,b,c)  



if __name__ == '__main__':
    a = int(input("enter your first number"))
    b = int(input("enter your second number")) 
    c = int(input("enter your third number"))
    addition_fn(a,b)   
    addition_fn2(a,b,c)  
    
        

        
        
        
        
        
        
        
        