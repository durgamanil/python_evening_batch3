# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 09:03:57 2022

@author: durga
"""

#defination of the addition function
def addition_fn():
    '''
    this is my addition function
    sdkfjkdsfjksjdf
    sdfkjdsfkjdskf
    dsfkjdsfkjds
    dsflkjdskfjdsk
    sfkjdskfjdskfjds
    

    '''
    print("this is inside manoj fun")
   



if __name__ == '__main__':  #main function

    #addition_fn()   #this is the function call
    print(addition_fn.__doc__)
