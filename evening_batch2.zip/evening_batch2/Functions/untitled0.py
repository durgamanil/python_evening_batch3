# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 19:08:00 2022

@author: durga
"""

def func1():
    print("this is coming from func1")
    
    
def func2():
    print("this is coming from func2")
    
    
def func3():
    print("this is coming from func3")