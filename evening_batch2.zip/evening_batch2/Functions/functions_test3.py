# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 08:57:42 2022

@author: durga
"""
def meghana_fn():
    print("this is inside meghana fun")
    print("this is the end of the line in meghana function")
    

def manoj_fn():
    print("this is inside manoj fun")
    print(30+40)
    print(10+20)
    print("this is the end of the line in function")



if __name__ == '__main__':  #main function
    #print(50+40)
    print("iam in main funtion")
    print("function testing is going on ")
    print("="*30)
    manoj_fn()   #this is the function call
    # print("="*30)
    # print("this is after function call")
    print("="*30)
    meghana_fn()
    print("="*30)
    print("this is after function call")
    
    
    