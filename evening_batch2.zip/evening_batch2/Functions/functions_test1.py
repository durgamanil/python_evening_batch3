# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 08:15:28 2022

@author: durga
"""

# =============================================================================
# functions
# =============================================================================

# method1:
# print("this is testing")
# print("this is testing1")
# print("this is testing2")
# print("this is testing3")

# print("this is testing4")
# print("this is testing5")
# print("this is testing6")
# print("this is testing7")

# print("this is testing8")
# print("this is testing9")

# method2:
# print("this is testing\n"*10)

# method3:
# for i in range(1,11,1):
#     print("this is testing",i)
    



# # =============================================================================
# # 10 times repeat the code
# # =============================================================================
# for i in range(0,10,1):
#     print("this is testing",i)
#     print("this is testing1")
#     print("this is testing2")
#     print("this is testing3")
#     print("this is testing4")
#     print("this is testing5")
#     print("this is testing6")
#     print("this is testing7")
#     print("this is testing8")
#     print("this is testing9")
    
    
# case 2:
# method1:
# a =10
# b =20
# c = a+b
# print(c)


# method 2:
# a =20
# b =30
# print(a+b)


# syntax:
    
# def function_name(args):
#     "logic comes here"
#     return values

#this is the function defination
def manoj_fn():
    print("this is inside manoj fun")
    print(30+40)
    print(10+20)



if __name__ == '__main__':  #main function
    #print(50+40)
    print("iam in main funtion")
    print("function testing is going on ")
    manoj_fn()   #this is the function call
    
    
    
    
    
    
    
    
    
    
    




    










