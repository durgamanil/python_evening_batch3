# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 19:57:48 2022

@author: durga
"""

#assignment opearators
#print(10+20)


a = 10
b = 10

# +=----->it add and  append to same variable
a =  a+10
print(a)


a += 10  #=====>a = a+10

#-= substract then assign

a = 20
a = a - 10
print(a)





a = 20
a -= 10
print(a)



#*= multiplication and assign
a = 20
a = a * 10
print(a)



a = 20
a *= 10
print(a)

#/= divide and assign

a = 20
a = a / 10
print(a)



a = 20
a /= 10
print(a)


#%= modulus and assign

print(5%4)

a = 18
a = a%4
print(a)










