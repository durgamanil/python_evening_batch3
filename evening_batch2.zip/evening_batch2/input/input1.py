# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 18:34:50 2022

@author: durga
"""

a = input("please enter your name")
print(a)


# =============================================================================
# RAW input
# =============================================================================
raw_input()#2.0 input function


a = int(input("please enter your name"))
print(a)
print(type(a))


a = float(input("please enter your name"))
print(a)
print(type(a))



