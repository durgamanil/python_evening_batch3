# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 18:44:19 2022

@author: durga
"""

control statements

if 


if
else:
    
    
if 
elif 
else:
    
    
syntax:
    if condition:
        statements
        


example1:
    
    
tickets = 2

if tickets == 2:
    print("they will watch the RRR movie")
    
    
    
example2:
    
    
tickets = 2

if tickets == 1:
    print("they will watch the RRR movie")
        

    
print("out of the loop")


example3:
    
    
tickets = 2

if tickets == 3:
    print("they will watch the RRR movie")
        

print("out of the loop")


example4:
    
    
if 0 == 0:
    print("they will watch the RRR movie")
    
    
    
if True:
    print("they will watch the RRR movie")
        

if 1:
    print("they will watch the RRR movie")
    
    
    
if 0:
    print("they will watch the RRR movie")
    
if False:
    print("they will watch the RRR movie")
    

    
# =============================================================================
# if else
# =============================================================================

syntax:
    if condition:
        statements
    else:
        statements
    
    
example1:
    
tickets = 2

if tickets == 2:
    print("they will watch the movie")
else:
    print("they will go shopping")
    

example2:
    
tickets = 2

if tickets == 1:
    print("they will watch the movie")
else:
    print("they will go shopping")
    
    
# =============================================================================
# if elif else
# =============================================================================
    
syntax:
    if condition:
        statements
    elif condtion:
        statements
    else:
        stements
    
    
example1:
    

tickets = 2

if tickets == 1:
    print("naveen only watch the movie")
    
elif tickets ==2:
    print("they will watch the movie")
    
else:
    print("they will go shopping")
    
example2:
    

marks = 45

if marks > 60:
    print("first class")
    
elif marks < 60 and marks>50:
    print("second class")
    
else:
    print("just pass")


#assignment
1. need to enter the marks
2. marks >80  grade A
3. marks 70> and <80 it grade B
4. marks 60> and <70 it grade C
5. marks 45> and <50 it grade D
6. marks <45 fail



