# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 20:05:56 2022

@author: durga
"""

a = input("enter your pin")

print(a)



#print(input("enter your pin"))

a = input("enter your pin")

print(a)
print(type(a))


# =============================================================================
# typecasting
# =============================================================================
a = int(input("enter your pin"))

print(a)
print(type(a))


b = "1234"
print(type(b))


print(type(int(b)))



b = 1234
print(type(b))

print(type(str(b)))
print(b)




