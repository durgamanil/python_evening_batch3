# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 20:16:37 2022

@author: durga
"""

# =============================================================================
# accepting input
# =============================================================================

# syntax:
#     input()
#     input("please enter your name")
    
#     #input will return string as a output
    
# ex:

# a = input() 
# print(a)   

# a = input("please enter your name") 
# print(a) 
# print(type(a))  

# num1 = input("please enter number")
# print(num1)
# print(type(num1))  


# num2 = input("please enter number")
# print(num2)
# print(type(num2)) 

# print(num1+num2)


#if we want in integer type we need typecast that 
# num1 = int(input("please enter number"))#type casting to integer
# print(num1)
# print(type(num1))  


# num2 = int(input("please enter number"))#type casting to integer
# print(num2)
# print(type(num2)) 

# print(num1+num2)


# num1 = int(input("please enter number"))#type casting to integer
# print(num1)
# print(type(num1))  


# num2 = int(input("please enter number"))#type casting to integer
# print(num2)
# print(type(num2)) 

# print(num1+num2)


#float type
# num1 = int(input("please enter number"))#type casting to integer
# print(num1)
# print(type(num1))  


# num2 = float(input("please enter number"))#type casting to integer
# print(num2)
# print(type(num2)) 

# print(num1+num2)


# #tasks 
# 1.insert the card number we need to validate that
# 2.we need to enter the password
# 3.we need to enter the cash
# 4.should show cash is dispensed msg


card_num = int(input("please enter the card number"))
print(card_num)
pass1 = int(input("please enter the password"))
cash = int(input("please enter the cash"))
print("cash is dispensed msg",cash)

#task2
1.calculator
2.collect the two inputs from the user
3.addition operation
4.substration operation(collect from user)
5.multiplication operation(collect from the user)
6.division operation(collect from the user)
7. you need to proceed with same result



2.x version python you will see raw_input()
#raw_input is deprecated in 3.x

