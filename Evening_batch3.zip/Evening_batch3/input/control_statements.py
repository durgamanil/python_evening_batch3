#control statements
# 1.if
# 2.if else
# 3.if elif else

# syntax:
#     if condition:
#         """statements"""

# tickets = 1
# persons = 1
# if tickets == persons: 
#     print("nadeesh entered into hall")


tickets = 1
persons = 2
if tickets == persons: 
    print("nadeesh entered into hall")


print("outof the if")


tickets = 4
persons = 2
if tickets >= persons: 
    print("nadeesh entered into hall")


print("outof the if")



tickets =5

if persons:
    print("nadeesh entered intoHall")

print("out of if")




if 1:
    print("nadeesh entered intoHall")

print("out of if")


if 0:
    print("nadeesh entered intoHall")

print("out of if")


if True:
    print("nadeesh entered intoHall")

print("out of if")


if False:
    print("nadeesh entered intoHall")

print("out of if")



if 100:
    print("this will  work")


if -10:
    print("this will  work")
    
    
if "rama":
    print("sita is looking for rama")
    
# =============================================================================
# if else    
# =============================================================================
syntax:
    
    if condition:
        """statements"""
    else:
        """statements"""
        
        
ex1:

tickets = 1
nadeesh_gf = 2

if tickets == persons: 
    print("nadeesh and gf entered into hall")
else:
    print("they will go to park")


tickets = 2
nadeesh_gf = 2

if tickets == persons: 
    print("nadeesh and gf entered into hall")
else:
    print("they will go to park")
    
    
#else will not work individually
tickets = 2
nadeesh_gf = 2


else:
    print("they will go to park")
    
    
    
# =============================================================================
# if elif else
# =============================================================================
syntax:
    if condition:
        """statemnets"""
    elif condition2:
        """statements"""  
    else:
        """statements"""

ex3:

tickets = 3
nadeesh_gf = 2

if tickets == persons: 
    print("nadeesh and gf entered into hall")
    
elif tickets == 3:
    print("nadeesh will call another gf")
    
else:
    print("they will go to park")  
    

task1:
1.student marks based grade system
2. you need to take the marks from the user(100)
3.1.if above 90 marks --->A+ grade
4.if >80 and <90 ---->A grade
5.>60 and <80----->B grade
6.>40 and <60---->C grade
7.<40-----> achieved top marks in the class

    
    
    
