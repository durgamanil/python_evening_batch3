from platform import python_branch


#integer in python
#================================================================
a =10
# 10 integer type
# a is variable---->integer

b =3000
#3000 is number type integer
#b is variable type is integer

print(a)

#by using inbuilt function called type
print(type(a))

print(b)
print(type(b))

c = -1
print(c)
print(type(c))

d = 756782435672436746357675675624375674367546357863476
print(d)
print(type(d))



