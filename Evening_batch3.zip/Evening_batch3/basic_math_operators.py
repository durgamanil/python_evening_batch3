# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 20:10:16 2022

@author: durga
"""

Operation on Numbers 
•	Addition 
•	Subtraction 
•	Multiplication 
•	Division 


#BODMAS rule
B-->brackets
O--->of
D---->Division
M----->multiplication
A----->addition
S------>substraction

#addition

a = 1000
b = 2000
c = a + b
print(c)

a = 10000000000000000000000000000
b = 4324543857485748375843758743857487548754
c = a+b
print(c)


substraction---> '-'

a = 1000
b = 2000
c = a - b
print(c)


a = 1000
b = 2000
c = b - a
print(c)

Multiplication----->'*'

a = 10
b = 20
c = a*b
print(c)

num1 = 1000
num2 = 3000
res =  num1 * num2
print(res)

division operator

'/'---normal division output is float values
'//'---floar division output


a = 10/5
print(a)
print(type(a))

a = 10//5
print(a)
print(type(a))



a = 10/0
print(a)
#ZeroDivisionError: division by zero


#powers-'**'

a = 5 ** 2
print(a)
print(type(a))

a  = 100 ** 4
print(a)

a = 2 ** 32
print(a)


a = 2 ** 324
print(a)









