# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 20:46:39 2022

@author: durga
"""

# =============================================================================
#  logical operator
# =============================================================================

1.and 
2.or 
3.not


#and operation
a =10
b =20

a<5 and b<=20

(a > 5) and (b == 20)


#or operators

a = 30
b = 40

a <40 or b>50

a >20 or b <80


#not operator
not(True)
not(False)

a = 10

not(a <20)

a = 30
not(a ==30)











