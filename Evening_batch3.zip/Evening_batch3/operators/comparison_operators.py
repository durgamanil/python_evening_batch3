# -*- coding: utf-8 -*-
"""
Created on Tue Jun 14 20:04:58 2022

@author: durga
"""

# =============================================================================
#  comparison operators
# =============================================================================

1.== equal
2.!= not equal
3.> greater than
4.< Less than
5.>= greater than or equal to
6.<= less than or equal to 


x = 10
y = 10

print(x == y)

x = 10
y = 30

print(x == y)

# not equal to

x = 10
y = 30

print(x != y)


x = 10
y = 10

print(x != y)

#> greater than

x = 10
y = 10

print(x > y)

x = 20
y = 10

print(x > y)

x = 5
y = 10

print(x > y)

#4.< Less than

x = 5
y = 10

print(x < y)

x = 10
y = 10

print(x < y)

x = 10
y = 5

print(x < y)

#5.>= greater than or equal to
x = 10
y = 5

print(x >= y)

x = 20
y = 30

print(x >= y)


x = 20
y = 20

print(x >= y)

print(30 >=20)


#6.<= less than or equal to 

x = 20
y = 20

print(x <= y)

x = 20
y = 30

print(x <= y)

a = "anil"
b = "roja"

print(a <= b)

a = "anil"
b = "anil"

print(a <= b)


a = "roja"
b = "anil"

print(a <= b)










