# -*- coding: utf-8 -*-
"""
Created on Wed Jun 15 20:08:38 2022

@author: durga
"""

# =============================================================================
# Membership operators
# =============================================================================
1.in 
2.not in

1.in operators--->it will return True if
 a word/sequence matches with specified string/value is present object
 if it not a member then it will return False
 
 
list1 = ["apple","orange","banana"]

print("banana" in list1)

print("mangoes" in list1)


#not in
it will return True if the word/sequence not matches 
if it matches then return False:
    
    
    
list1 = ["apple","orange","banana"]

print("banana" not in list1)

print("mangoes" not in list1)



