# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 20:25:53 2022

@author: durga
"""

#operator

assignment operator


a = 10*5
print(a)
a = a*5
print(a)

'+='---->addition and assignment

a =10
a +=5  #====> a= a+5
print(a)

'-='------> substraction and assign
a = 20
a -= 10  # a = a-10
print(a)


'*='----------> multiplication and assign

a = 20
a *= 5 # a =a*5
print(a)

'/='----------> division and assign

a = 40
a /= 5
print(a)

a /= 8
print(a)

'//='-------> division and assign
a = 40
a //=8
print(a)

#bitwise operator
"&=" bitwise and then assign

a = 10
a &=1
print(a)

"|=" bitwise or then assign

a = 4
a |=2
print(a)














