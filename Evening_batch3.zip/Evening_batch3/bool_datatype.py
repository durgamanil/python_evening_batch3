# -*- coding: utf-8 -*-
"""
Created on Fri Jun 10 21:20:56 2022

@author: durga
"""

# bool
# ====

1.True
2.False

True indicated --1
False indicated --0

a = True
print(a)
print(type(a))

b = False
print(b)
print(type(b))




