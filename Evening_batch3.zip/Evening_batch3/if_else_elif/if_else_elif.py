# -*- coding: utf-8 -*-
"""
Created on Mon Jun 20 20:08:53 2022

@author: durga
"""
a = int(input("please enter a number"))

if (a >80) and (a <90):
    #print("this is testing")
    if (a >81) and (a<85):
        print("A++")
    elif (a<90) and(a>=85):
        print("A+++")
        

        