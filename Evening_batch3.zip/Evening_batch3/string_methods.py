#methods of the strings
#==============================

c = "this is 'india' biggest project"
# print(c[0])
# print(c[1])
# print(c[2])
# print(c[3])
# print(c[4])
# print(c[5])
# print(c[6])


#reverse indexing
print(c[-1])
print(c[-2])
print(c[-3])
print(c[-4])
print(c[-5])
print(c[-6])

c = "this is 'india' biggest project"
c.capitalize()