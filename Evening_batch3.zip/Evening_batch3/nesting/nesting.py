#loop control statements
1.For loop
2.while

1.for loop:
	 it will excute on the condition. it will stop once the condition is failed
	 
2.while loop:
	unstoppable loop if condition is true(condition fails then it will stop)
	
	
#syntax:
	for variable_name in datatype(list,tuple,dictionary,set,strings):
		"""statements"""
	
	for variable_name in range(start,stop,step):
		"""statements"""


list1 = [1,2,3,4,5]
		
for i in list1:
	print(i)
    
    
tuple1 = (1,2,3,4,5)
		
for i in tuple1:
	print(i)
    
    
tuple1 = (1,2,3,4,5)
		
for i in tuple1:
	print(i)
    print(type(tuple1))   
    
tuple1 = (1,2,3,4,5)
print(type(tuple1))		
for i in tuple1:
	print(i)    
    
    
    
    
    
    
    