
for i in range(0,10,2):
    print("this is testing",i)
    
#    o/p:0,2,4,6,8
 