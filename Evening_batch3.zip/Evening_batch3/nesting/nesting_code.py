python Introduction

python invented in 1991
the father of python is guido vann rossum

1.what is Tiobe index ranking
