# -*- coding: utf-8 -*-
"""
Created on Fri Jun 10 21:33:22 2022

@author: durga
"""

complex()
=================================
a+bj
a=real number
b =imaginary number

s = 4 + 5j

print(s) 
print(type(s))

example2:

s = 5j
print(s) 
print(type(s))
