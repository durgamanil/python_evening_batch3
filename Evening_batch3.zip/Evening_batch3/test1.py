# -*- coding: utf-8 -*-
"""
Created on Tue Jun  7 21:05:15 2022

@author: durga
"""
a = 10



print("this is testing")
print("Hello Evening batch3")
print("this is testing")
print("Hello Evening batch3")
print("this is testing")
print("Hello Evening batch3")
print("this is testing")
print("Hello Evening batch3")
print(d)
print("this is testing121212")
print("Hello Evening batch3")
print("this is testing")
print("Hello Evening batch3")
print("this is testing")
print("Hello Evening batch3")
print("this is testing")
print("Hello Evening batch3")

print("this is testing")
print("Hello Evening batch3")
