# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 20:09:15 2022

@author: durga
"""

# =============================================================================
# while
# =============================================================================
while is also condition based loop:
    
when condition is true....it will goes to inside the loop
else it will come out from the loop
while is unstoppable loop until condition fails


syntax:
    while condition:
        """statements"""
        


examples1:
    
a = 10

while a == 10:
    print("inside while loops")
    
#    
a = 10

while a > 10:
    print("inside while loops")   
    
print("out side while")    
    
#example3

a = 10

i = 1
while 20 > 10:
     
    i +=1
    print("inside while loops",i)  
    
    
print("out side while")    



#monkey fellow interview
#indentation
i = 1
while True:
    i +=1
    print("inside while loops",i)  
    
print("out side while")  


i = 1
while False:
    i +=1
    print("inside while loops",i)  
    
print("out side while")  

#
a = 20
while a<40:
    a +=1 #a = a+1
    print(a)
    
    
# 
while 1:
    print("testing")
    

while 0:
    print("not testing")

    
    
    
    
    
    
    
    
    
    