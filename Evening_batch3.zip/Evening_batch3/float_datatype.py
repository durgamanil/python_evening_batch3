#float indicates for point values
#================================================================
a = 12.5
print(a)
print(type(a))

b = 134.567
print(b)
print(type(b))


c =123455667778.375687874358675486758467584768547689435685768
print(c)
print(type(c))


c =1234.375687874358675486758467584768547689435685768
print(c)
print(type(c))

#dir will display all the methods of the datatype
dir(float)


