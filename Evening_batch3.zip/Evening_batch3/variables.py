# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 20:12:32 2022

@author: durga
"""

# =============================================================================
# 
# =============================================================================
print("this is testing")

print("this is yet another test")


a = 10
print(a)

id(a)
print(id(a))


a =20
print(a)
print(id(a))

b =20
c =30

print(b)
print(c)

myvar = 10
print(myvar)
print(id(myvar))



123abc =20

abc123 =20

@1234 = 20

1234 = 40

abc_123 =50 
print(abc_123)

sampath_kumar =30
raja_vikra_marka =30

mahendra_bahubali_is_the_son_of_amerendra_bahubali = 50

* =30


a =10
b =10
c =10
print(a)
print(b)
print(c)

print(id(a))
print(id(b))
print(id(c))


print("=========================")
b = 20
print(b)
print(id(b))


#acd =10
#b =20


a =10
d =10
c =10
b =10
print(a)
print(d)
print(c)
print(b)

print(id(a))
print(id(d))
print(id(c))s
print(id(b))


print("=========================")
b = 20
print(b)
print(id(b))








 







