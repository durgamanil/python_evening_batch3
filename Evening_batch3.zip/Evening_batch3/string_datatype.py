#string DataType indicate the words
#=============================

s = "india"
print(s)
print(type(s))

name = 'veeresham'
print(name)
print(type(name))

# c = "this is india"s biggest project"
# print(c)
# print(type(c))

c = "this is india's biggest project"
print(c)
print(type(c))

c = "@"
print(c)
print(type(c))

c = 'this is india"s biggest project'
print(c)
print(type(c))


c = 'this is "india" biggest project'
print(c)
print(type(c))

c = "this is 'india' biggest project"
print(c)
print(type(c))



