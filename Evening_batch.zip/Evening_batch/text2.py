# -*- coding: utf-8 -*-
"""
Created on Sun Feb 20 17:30:57 2022

@author: durga
"""

# user_name= input("please enter user name")
# print("\n",user_name)
# address = input("please enter address")
# print("\n",address)

mobile_number =  int(input("please enter your mobile number"))
# =============================================================================
# validation of mobile number
# =============================================================================

print(mobile_number)

# id1 = input("enter your id")
# print(id1)


