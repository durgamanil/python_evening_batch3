# -*- coding: utf-8 -*-
"""
Created on Mon Feb 14 16:25:36 2022

@author: durga
"""

a =10
print(id(a))
print("hello chary",a)
b =10
print(id(b))
print("hello chary",b)
sunny = 10
print(id(sunny))
print("hello chary",sunny)

a =20
print(id(a))
print("brahmi",a)
a =30
print(id(a))
print("nayana",a)

