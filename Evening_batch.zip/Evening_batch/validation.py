

a ="123"

print(len(a))


# for i in range(0,len(a)):
#     b = a%10
#     b = a//10
#     b = b%10
#     print(b)



# c = a%100
# print(c)
# d =c%10
