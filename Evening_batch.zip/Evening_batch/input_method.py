# -*- coding: utf-8 -*-
"""
Created on Sun Feb 20 17:19:38 2022

@author: durga
"""

a = int(input("please enter a number"))
print("this is a",a)
b = int(input("please enter second number"))
print("this is a",b)
c = a+b
print("c=",c)
