# -*- coding: utf-8 -*-
"""
Created on Tue Mar 22 07:26:17 2022

@author: durga
"""

from  tkinter import * 
import tkinter as tk


# def window():
#     print("This is tkinter")
    
    


# if __name__ == '__main___':
#     window()


root = Tk()

root.geometry("400x600")
root.title("Calculator")

for i in range(0,100):
    
    label1 = tk.Label(root,text="ATM PROJECT")
    label1.grid()


root.mainloop()


# =============================================================================
# label and title
# =============================================================================

root = Tk()

root.geometry("400x600")
root.title("Calculator")


    
label1 = tk.Label(root,text="ATM PROJECT")
label1.grid()


root.mainloop()





