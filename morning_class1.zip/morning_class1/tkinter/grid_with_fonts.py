# -*- coding: utf-8 -*-
"""
Created on Wed Mar 23 06:56:49 2022

@author: durga
"""


from  tkinter import * 
import tkinter as tk



root = Tk()

root.geometry("400x600")
root.title("Calculator")


    
label1 = tk.Label(root,text="ATM PROJECT", font = ("Comic Sans MS",28))
label1.grid()

label1 = tk.Label(root,text="ATM PROJECT", font = ("Arial",28))
label1.grid()

label1 = tk.Label(root,text="ATM PROJECT", font = ("Arial",10))
label1.grid()

label1 = tk.Label(root,text="ATM PROJECT", font = ("Arial",100))
label1.grid()


root.mainloop()
