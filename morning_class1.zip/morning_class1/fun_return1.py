# -*- coding: utf-8 -*-
"""
Created on Fri Feb 25 07:36:11 2022

@author: durga
"""

def fun1(c):
    a = 10
    sum = 10+c
    return sum


ret_sum = fun1(20)
print(ret_sum)

