# -*- coding: utf-8 -*-
"""
Created on Sat Mar  5 07:11:46 2022

@author: durga
"""

# =============================================================================
# same name functions

# =============================================================================


# def a():
#     print("this is function a")
    
# def a():
#     print("this is function b")
    
    
# print(id(a()))
# print(id(a()))

# def a(b,c):
#     print("this is function b",b,c)

# def a(b):
#     print("this is function a",b)
    

# a(20,30)  
# a(10)



class A:
    print(" this is sfirsr aaa")

class A:
    print("thisi sis thiskjksdjfkjsdkf")


print(A)

