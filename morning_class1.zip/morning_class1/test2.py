# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 07:41:40 2022

@author: durga
"""

#syntax:
    
try:
        """statements"""
except:
    """error msgs"""
    """system should come out"""
    


