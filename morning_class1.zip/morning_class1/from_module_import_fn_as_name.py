

#from utility_math import add_fn,sub_fn,div_fn,mul_fn

from utility_math import add_fn as add


print("this is module testing")
#add_fn(10,20)

c = add(10,20)
print(c)


print(add(10,20))


