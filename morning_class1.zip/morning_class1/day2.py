# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 07:09:12 2022

@author: durga
"""

# name = input("Enter your name")

# print(type(name))



# card_number = int(input(" enter card number\n"))

# print(card_number,type(card_number))


# #type casting
# int()
# str()
# float()
# list()
# dict()
# bool()


# # =============================================================================
# # conditional statement
# # =============================================================================


# if condition:
#     print("statement")


# if condition:
#     """statement"""
# else:
#     """statements"""
    
    
# if condition:
#     """statements"""
# elif condition2:
#     """statements"""
# else :
    # """statements"""
    
# =============================================================================
# 
# =============================================================================
#int , str, float,list, dict,tuple

# existing_pin = 1234


# pin_num = int(input("Enter your pin number"))
# print(pin_num,type(pin_num))


# if existing_pin == pin_num:
#     print(f"matching the pin{pin_num}")
    
    

# pin_num = input("Enter your pin number")
# print(pin_num,type(pin_num))

# if existing_pin == pin_num:
#     print(f"matching the pin{pin_num}")

# else:
#     print(f"not matching the pin{pin_num}")


# =============================================================================
# checking the pin is matching or not
# =============================================================================


# for variable_name in function_list:
#     """statemnts"""
    
# range(start,stop, step)
# start =0
# step =1
# stop= stop-1
# range(0,100,1)
    
for i in range(0,3,1):
    #existing_pin = 1234
    print(i)


# pin_num = int(input("Enter your pin number"))
# print(pin_num,type(pin_num))


# if existing_pin == pin_num:
#     print(f"matching the pin{pin_num}")
    
    
    













