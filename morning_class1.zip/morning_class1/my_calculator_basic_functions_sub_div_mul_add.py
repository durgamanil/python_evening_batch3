# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 06:51:47 2022

@author: durga
"""


def add_fn(a,b):
  print(a+b)

def sub_fn(a,b):
  print(b-a)

def div_fn(a,b):
  print(a//b)

def mul_fn(a,b):
  print(a*b)

