# -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 07:48:28 2022

@author: durga
"""

def add_fn(a,b):
  c = a+b
  return c

def sub_fn(a,b):
  print(b-a)

def div_fn(a,b):
  print(a//b)

def mul_fn(a,b):
  print(a*b)


