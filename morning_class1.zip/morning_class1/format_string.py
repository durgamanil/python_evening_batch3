# -*- coding: utf-8 -*-
"""
Created on Sat Feb 26 19:51:23 2022

@author: durga
"""
a =10
print(f"this is text{a}")

a ="madhusudhan"
print(f"this is text{a}")

a,b,c = True,20.01,"kdsjkjdskfjsdkfjkjsdf"
print(f"this is text-------{a},{b},{c}")
print(F"this is text-------{a},{b},{c}")
print(f'this is text-------{a},{b},{c}')
print(F'this is text-------{a},{b},{c}')
