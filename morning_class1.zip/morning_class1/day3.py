# -*- coding: utf-8 -*-
"""
Created on Thu Jan 27 07:27:10 2022

@author: durga
"""


#list()
#list1 = [datatype1,datatype2,datatype3] 

list1 =[10,20,30,40]


#similar datatype
print(list1)
print(type(list1))

print(list1[0])
print(list1[1])
print(list1[2])
print(list1[3])

print(type(list1[0]))
print(type(list1[1]))
print(type(list1[3]))
print(type(list1[2]))


#list reverse index
print("reverse index")
print(list1[-1])
print(list1[-4])
print(list1[-2])
print(list1[-3])


print(id(list1))
print(id(list1[0]))
print(id(list1[1]))
print(id(list1[2]))
print(id(list1[3]))

list2 = ['vodka','beer','kf','BW','coke']

print(type(list2))
print(list2[0])
print(list2[1])
print(list2[2])
print(list2[3])
print(list2[4])

print(list2[5])#

print(list2[100])

print(list2[-10])



#different data type

list3 = ["flower1",12,34.5,True]

print(list3[0])
print(list3[1])
print(list3[2])
print(list3[3])

#print(list3[4])

print(type(list3[0]))
print(type(list3[1]))
print(type(list3[2]))
print(type(list3[3]))

#list
list3 = ["flower1",12,34.5,False]

print(list3[0])
print(list3[1])
print(list3[2])
print(list3[3])

#print(list3[4])

print(type(list3[0]))
print(type(list3[1]))
print(type(list3[2]))
print(type(list3[3]))








