

import utility_math as c
import pandas as pd


file_path = c.__file__
print(file_path)


pandas_path = pd.__file__
print(pandas_path)

# D:\python\morning_class\utility_math.py
# C:\Users\durga\anaconda3\lib\site-packages\pandas\__init__.py




