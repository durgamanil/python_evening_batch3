# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 07:37:37 2022

@author: durga
"""

import utility_math as c

print(c.__doc__)
print(c.__file__)
print(c.__name__)
print(c.__package__)