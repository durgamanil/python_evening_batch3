# -*- coding: utf-8 -*-
"""
Created on Mon Feb 28 15:52:55 2022

@author: durga
"""


for j in range(0,10):
    for i in range(0,10):
        if i ==1:
            print(i)
            break
        else:
            print(i)

#break
print("color is different")