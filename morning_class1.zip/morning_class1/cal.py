# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 07:30:57 2022

@author: durga
"""

a = 5*3+4-6*(4*1)+5
print(a)