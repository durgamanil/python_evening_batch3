# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 07:22:20 2022

@author: durga
"""

#python is dynamically typed language
a ="100000000000000000000000000000000000000000000000000000000000000000000000000000000000000"

print(type(a))


Client Name

veeravenkatasatyanarayanaaccount=10000

VVeeraenkataSatyaNarayanaAccount=10000
veeraVenkataSatyaNarayanaAccount=10000
PEP8 rules

veera_venkata_satya_narayana_account =10000


a ="10.0"
b=20
c=30.7
d=True

print(a,type(a))


#print methods

print(a,b,c,d)
print("this value",a,b)
print(f'this {a} value')

print(f'a:{a},b:{b},c:{c},d:{d}')
print('a:{0},b:{1},c:{2},d:{3}'.format(a,b,c,d))

print('a:{1},b:{2},c:{0},d:{3}'.format(a,b,c,d))

print('a:{1},b:{2},c:{0},d:{3}'.format("ramya",10,10.1,False))


NOTE:python 2.0

print a
    
#statically typed language


#int a= 10
#float a =10.9
#str name = "radha"


naming convention

1.camel------Client Name
2.pascal
3.snake code