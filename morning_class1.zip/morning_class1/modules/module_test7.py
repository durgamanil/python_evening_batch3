# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 07:42:28 2022

@author: durga
"""

import utility_math as math
import utlity_email as email



c = math.add_fn(10, 50)
print(c)

d = email.add_fun2(c, 40)
print(d)

