# -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 07:51:03 2022

@author: durga
"""


#syntax : import filename

#import utility_math

from utility_math import add_fn
from utility_math import sub_fn
from utility_math import div_fn
from utility_math import mul_fn



print("this is module testing")
add_fn(10,20)
sub_fn(20,10)
div_fn(30,10)
mul_fn(56,2)
