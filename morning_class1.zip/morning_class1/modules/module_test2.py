
#from utility_math import add_fn,sub_fn,div_fn,mul_fn

from utility_math import add_fn as add


print("this is module testing")
add_fn(10,20)
sub_fn(20,10)
div_fn(30,10)
mul_fn(56,2)

