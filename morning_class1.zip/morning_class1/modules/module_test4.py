

import my_calculator_basic_functions_sub_div_mul_add
import utility_math


print(utility_math)
print(utility_math.__doc__)
print(utility_math.__name__)
print(utility_math.__package__)
print(utility_math.__file__)
#dir(__utility_math__)


#from my_calculator_basic_functions_sub_div_mul_add import add_fn

my_calculator_basic_functions_sub_div_mul_add.add_fn(10,40)

my_calculator_basic_functions_sub_div_mul_add.add_fn(10,60)

my_calculator_basic_functions_sub_div_mul_add.sub_fn(30, 50)

my_calculator_basic_functions_sub_div_mul_add.mul_fn(5000, 15)