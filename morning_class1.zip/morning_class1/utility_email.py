

def send_email(to,cc,subject,attachment,body):
    print(to)
    print(cc,subject,attachment,body)
    
    
def add_fun2(a,b):
    c = a+b
    return c