# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 06:48:07 2022

@author: durga
"""

from utility_math import *


print("this is module testing")
add_fn(10,20)
sub_fn(20,10)
div_fn(30,10)
mul_fn(56,2)