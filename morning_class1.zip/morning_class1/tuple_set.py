# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 06:31:55 2022

@author: durga
"""

# tuple1 = (10,"test",55.4,False)

# print(tuple1)
# print(type(tuple1))

# tuple1 = (10,"test",55.4,False,10,20,30)

# print(tuple1)
# print(type(tuple1))

# tup2 = list(tuple1)

# tup2.append(50)
# print(tup2)

# tuple1 = tuple(tup2)
# print(tuple1)



# set1 = set()
# print(set1)
# print(type(set1))



set1 = {50,10,20,30,10,40}
print(set1)
print(type(set1))






