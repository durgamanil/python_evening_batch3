
# a = 10
# b = 20

# c = a+b
# print("a =",a)
# print("b =",b)
# print("c =",c)


def sum_fn():
    print("this is tesing1")
    print("this is tesing1")
    print("this is tesing1")
    print("this is tesing1")
    print("this is tesing1")
    print("this is tesing1")
    print("this is tesing1")
    print("this is tesing1")

sum_fn()