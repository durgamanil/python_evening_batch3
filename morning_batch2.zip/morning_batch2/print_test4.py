# -*- coding: utf-8 -*-
"""
Created on Tue May 31 08:46:58 2022

@author: durga
"""

#print "this is testing" #python 2.x version
a =10
print(id(a))

b=10
print(id(b))

c=10
print(id(c))

print("this is testing")
print('this is testing')

print("this is testing")
print('this is 'testing'')#SyntaxError: invalid syntax

print("this is 'testing'")
print('this is "testing"')

print("this is anil's class")

a =10
print(id(a))

b=10
print(id(b))

c=10
print(id(c))

print("="*30)

a =100
print(a)
print("a",id(a))
print(id(c))
print(id(b))

