# num = 10

# a = 1
# while num == 10:
#     a =a+1
#     print(a)



# num = 1
# while num <= 10:
#     print(num)
#     num = num+1


from ast import keyword


# num = 1
# while num <= 1000:
  
#     num = num+1
#     print(num)
#     if num == 100:
       
#         print("this is matched")


# break keyword
# ================================================================
# it will stop the process 

# num = 1
# while num <= 1000:
  
#     num = num+1
#     print(num)
#     if num == 100:
#         print("this is matched")
#         break
    


# continue keyword
# ========================================
# it will continue the process


num = 1
while num <= 1000:
  
    num = num+1
    print(num)
    if num == 100:
        print("this is matched")
        continue

    