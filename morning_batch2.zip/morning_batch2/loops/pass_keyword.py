# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 08:13:07 2022

@author: durga
"""

# =============================================================================
# pass
# =============================================================================

def function():
    #print("this is testing")
    pass
    
    
function()


#ex2:
    
a =10
if a ==10:
   #print("this is a",a)
   #pass
   
   
#ex3 :
    
    
for i in range(0,10,1):
    #print(i)
    pass



    
    