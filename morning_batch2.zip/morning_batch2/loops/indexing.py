# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 08:23:06 2022

@author: durga
"""

list1 = [1,2,3,4,5]

# =============================================================================
# how to call index?
# with square braskets:
# =============================================================================
print(list1[0])
print(list1[1])
print(list1[2])
print(list1[3])
print(list1[4])

# reverse index
print(list1[-1])
print(list1[-2])
print(list1[-3])
print(list1[-4])
print(list1[-5])



for i in range(0,5):
    print(list1[i])
    
    
for i in range(5,0,-1):
    print(list1[-i])
    
str1 = "india"

print(str1[0])
print(str1[1])
print(str1[2])
print(str1[3])
print(str1[4])


print(str1[-1])
print(str1[-2])
print(str1[-3])
print(str1[-4])
print(str1[-5])





