# for i in range(0,10,1):
#     print("this is testing for loop")

# for i in range(0,10,1):
#     print(i)

# for i in range(0,10,2):
#     print(i)

# for i in range(0,10,3):
#     print(i)

# for i in range(0,10,4):
#     print(i)


# for i in range(0,10,):
#     print(i)


# for i in range(10,):
#     print(i)


# for i in range(5,101,5):
#     print(i)


#nesting for
# for i in range(0,5,1):
#     for j in range(0,10,1):
#         print(i,j)



# for i in range(0,5,1):
#     for j in range(0,10,1):
#         print(i,j,sep ='-')

# for i in range(0,5,1):
#     for j in range(0,10,1):
#         print(i,j,sep ='@@@')


for i in range(0,5,1):
    for j in range(0,5,1):
        print("*",end='')
    print()



