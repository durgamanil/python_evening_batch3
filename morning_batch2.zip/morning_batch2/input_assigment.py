a = int(input("please enter the num1"))
b = int(input("please enter the num2"))
c = int(input("please enter the num3"))
d =  int(input("please enter the num4"))

e = a+b+c+d
print(e)