# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 08:19:32 2022

@author: durga
"""
a = 10

# print(a)
# print()#------> new line
# print("this is testing")
# print('this is testing')

b =10
c =20
d =30
print(a,b,c,d)
print("a=",a,"b=",b,"c=",c,"d=",d)

# "\n"-----> new line
# "\t"------>tab space
# "\r"------->return
# "\\"------->

print(a,b,c,d)
print("a=",a,"b=",b,"c=",c,"d=",d)
print("a=",a,"\n","b=",b,"\n","c=",c,"\n","d=",d)


first_name = "shailaja"
last_name = "mitapalli"

print("firstname:",first_name,"\n","last_name:",last_name)

# =============================================================================
# format strings
# =============================================================================

a = 10
b =40
c =20
d =30
print(a,b,c,d)
print("a ={} b ={} c ={} d= {}".format(a,b,c,d))


a = 10
b =40
c =20
d =30
print(a,b,c,d)
print("a ={} b ={} c ={} d= {}".format(b,a,c,d))



a = 10
b =40
c =20
d =30
print(a,b,c,d)
print("a ={0} b ={1} c ={2} d= {3}".format(a,b,c,d))
print("a ={1} b ={0} c ={2} d= {3}".format(a,b,c,d))


# =============================================================================
# format strings
# =============================================================================


print(f'a= {a}')
print(f'b= {b}')
print(f'c= {c}')
print("a ={0} b ={1} c ={2} d= {3}".format(a,b,c,d))
print(f"a ={a} b ={b} c ={c} d= {d}")
print(f'a ={a} b ={b} c ={c} d= {d}')
print(F'a ={a} b ={b} c ={c} d= {d}')
print(F"a ={a} b ={b} c ={c} d= {d}")



print("helloworld")
print()
print("this is testing")

print("helloworld")
print("this is testing")

print("helloworld \n this is testing")
#"\t" tab space
print("helloworld \t this is testing")
print("helloworld \t this is "testing"")
print('helloworld \t this is "testing"')
print("helloworld \t this is 'testing'")
print("shiva's computer shop")
print('shiva"s computer shop')

print("this is \ testing")
print("this is \\ testing")

print("this is / testing")
print("this is // testing")


print("welcome")
print("wel\rcome")
print("w\relcome")
print("\rwelcome")
print("welcome\r")

print("hello \rworld")
print("he\rllo world")














