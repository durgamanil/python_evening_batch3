a = raw_input("please enter a number")
print(a)