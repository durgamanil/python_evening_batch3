

a = 10
print(a)


#snake coding
venkata_bhasker =20 

abc_bac_cad_ghf =30

venkata_krishna_manohar =40

jfsdk_jkdsjkfjd_skfjdsk_fjdskfj=50

anil_durgam = 50


#camel_coding
venkataKrishnaManohar =40
chakriPawan =1000
mitapalliShailaja =100



#pascal coding

VenkataKrishnaManohar = 1000
SharathChandraIps=10000

addition_subration_multiplication_division_operation_variable1 =100
addition_subration_multiplication_division_operation_variable2 =200

addition_subration_multiplication_division_operation_sum = addition_subration_multiplication_division_operation_variable1+addition_subration_multiplication_division_operation_variable2
print(addition_subration_multiplication_division_operation_sum)
 


a =100
b =200
print(a+b)

mul_var =300
print(mul_var)
print(id(mul_var))
















