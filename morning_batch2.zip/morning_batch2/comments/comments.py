# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 08:52:45 2022

@author: durga
"""
#comments are mainly two types
#1.single line comments
#2. multiple line comments

#single line comments 
#"#"---by using this you can  comment the single line


#This is the test code
a=100
print(a)
#a=100

a = 1000 # a represent my sales


#multiline comments

"""------"""
#triple quotes at starting and triple quotes at ending also

"""
this is the code help for the calculation part
author : anil durgam
date:08-06-2022
modification:08-06-2022
version:v1
"""

print("end of the program")


'''
this is the code help for the calculation part
author : anil durgam
date:08-06-2022
modification:08-06-2022
version:v1
'''
print("end point")



