a = float(input("please enter item1\n"))
#this is type casting
b = float(input("please enter item2\n"))
c = float(input("please enter item3\n"))
d =a+b+c

print("Hello"," ",d)
print(type(d))