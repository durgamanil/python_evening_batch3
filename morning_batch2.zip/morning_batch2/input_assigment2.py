customer_name = input("please enter your name")
print(customer_name)
#greet
print("Good Morning "+" "+customer_name)