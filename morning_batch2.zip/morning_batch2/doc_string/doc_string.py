# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 09:01:04 2022

@author: durga
"""

doc string
syntax:
    
functionname.__doc__

def myname():
    """this is the function will show the logged user
    names it will display
    """
    a  =20
    print("a",a)
    
myname()
print(myname.__doc__)