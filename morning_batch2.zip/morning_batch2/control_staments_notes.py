# a =10

# if a ==10:
#     print("go to shop")

# print("end the of the program")

#================================================================================================================================a =10
# a = 10
# b = 20

# if a !=10:
#     print("go to shop")

# print("end the of the program")

# if a == 10 and b ==20:
#     print("this is the loop")



# tickets = 1
# if tickets ==1:
#     print("you will enter into the movie hall")

# if tickets !=1:
#     print("make another plan")


# tickets = 2
# if tickets ==2:
#     print("you will watch the movie")
# else:
#     print("only one tickers is available")

# #False
# tickets = 2
# if tickets ==1:
#     print("you will watch the movie")
# else:
#     print("only one tickers is available")

#if elif else
# tickets = int(input("enter tickets"))
# if tickets ==2:
#     print("you and your lover will watch the movie")
# elif tickets ==1:
#     print(" you only watch the movie")
# else:
#     print("you and your lover will go to park")   


#student marks
marks =int(input("enter the marks"))
if marks<35:
    print("you got very less marks")
elif marks>35 and marks<50:
    print("you got D rank")
elif marks >50 and marks <60:
    print("you got C rank")
elif marks>60 and marks<75:
    print("you got B rank")
else:
    print("you got A rank")







