# -*- coding: utf-8 -*-
"""
Created on Mon Jun  6 08:14:58 2022

@author: durga
"""

# =============================================================================
# Arithmetic operators
# =============================================================================

#addition "+" operator
print(10+20)
print(300+400)


#substraction
print(100-20)
print(1000-300)

print(1000000000000000000000000000-200000000)
print(50-100)

#multiplication operator
print(10*20)
print(1000000000000000000000000000*200000000000000000000000000000)

#division operator
print(20/10)
print(type(20/10))

print(20//10)
print(type(20//10))

#modulus
print(17%4)
print(type(17%4))







