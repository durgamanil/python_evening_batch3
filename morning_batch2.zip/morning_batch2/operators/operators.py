# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 08:30:42 2022

@author: durga
"""

# =============================================================================
# Bitwise operators
# =============================================================================
#1.& ==and 

a =2
b =3
print(a&b)

a =2
b =3
print(a|b)


a =2
b =3
print(a^b)


a = 5
print(~a)

a = 2
print(~a)

a=2
print(a>>1)

a=2
print(a>>2)
a=2
print(a>>10)

#
a =2
print(a<<1)

a =2
print(a<<2)

a =2
print(a<<5)

print(a)


a =2
a >>=5      #a = a>>5
#print(a>>=5)
print(a)
















