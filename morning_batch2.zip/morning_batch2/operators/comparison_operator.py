# -*- coding: utf-8 -*-
"""
Created on Tue Jun  7 08:08:49 2022

@author: durga
"""
# =============================================================================
# 3.comparison operators
# ============================
# 1."==" Equal
# 2."!=" not Equal
# 3.">" Greater than
# 4."<" Less than
# 5.">=" Greater than or Equal to 
# 6."<=" Less than or Equal to 
# =============================================================================

#Equal
2 == 3 # false
print(2 == 3)

print(2 == 2)#True

a = 10
b = 20

print(a == b)

#"!="
print( 10 != 20)#true
print(10 != 10)#false

a = 10
b = 20

print(a != b)


#greater than
print(2 > 3)#False
print(2 > 1)#True

a = 100
b = 200

print(a > b)#False
print(b>a)#True


#less than
print(2000<1000)#False
print(1150<1250)#True

a = 100
b = 200

print(a < b)#True
print(b < a)#False

#">=" Greater than Equal to 
print(50>=49)#True
print(49>=49)#True

a = 1000
b = 2000

print(a >= b)#False
print(b >= a)#True

#"<=" less than or Equal to 

print(50<=49)#False
print(49 <=49)#True

a = 1000
b = 2000

print(a <= b)#True
print(b <= a)#False
























