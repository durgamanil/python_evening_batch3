# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 08:12:47 2022

@author: durga
"""

number = 10  #integer type

print(10+20)

print(10+30)
print(10+40)

print(10+50)
print(number+50)


# =============================================================================
# Interger type
# =============================================================================
# variables names

# abc123  #correct
# num_ =10 #accepts
# 1243number#not acceptable
# number_add =10


# =============================================================================
# syntax:
#     type(variable)
# =============================================================================

num1 = 10 
print(number+50)
print(type(num1))


print(type(1))



num2 = 100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000

print(type(num2))
print(num2)

num3 = 200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000

num4 = num3+num2

print(num4)

# =============================================================================
# string data type
# =============================================================================


a = "manoj"
print(a)
print(type(a))

a = 'manoj'
print(a)
print(type(a))


#python dnot have character datatype

print('b')
print(type('b'))

print(type('^'))
print(type('@'))



# =============================================================================
# float data type
# =============================================================================

#12.5
#86.7
#11.12
#9.1234
#12.123456781234

print('12.5')
print(type('12.5'))#str

print(12.5)
print(type(12.5))

fl = 12.5
print(fl)
print(type(fl))


#
fl = 11.12
print(fl)
print(type(fl))


#9.1234
fl = 9.1234
print(fl)
print(type(fl))

#
fl = 12.123456781234
print(fl)
print(type(fl))

#
fl = 12.123456781234676767676767676767676767644543453547565765676767
print(fl)
print(type(fl))


# =============================================================================
# Bool
# =============================================================================

#0,1
#True,False

True
False

true
false

print(True)
print(type(True))

print(False)
print(type(False))


if True:
    print("this is testing")
    
if 1:
    print("this is testing")


# =============================================================================
# complex datatype
# =============================================================================

#5+6j
#5i+7j
#6j

print(5+6j)

print(type(5+6j))


#
print(5+7j)
print(type(5+7j))

print(7j)
print(type(7j))

#
print(5-7j)
print(type(5-7j))

















