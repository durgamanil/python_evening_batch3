# -*- coding: utf-8 -*-
"""
Created on Thu Jun  9 08:21:08 2022

@author: durga
"""

# =============================================================================
# Accepting inputs from the user

# =============================================================================

# a = input()
# print(a)


# a = input("please enter your name\n")
# print("Hello"+" "+a)


# a = input("please enter your name\n")
# print("Hello"+" "+a)
# print(type(a))

# a = input("please enter your roll no\n")
# print("Hello"+" "+a)
# print(type(a))

#type casting from string to integer

# a = int(input("please enter your roll no\n"))#this is type casting
# print("Hello"," ",a)
# print(type(a))


#float type casting from string to float
# a = float(input("please enter your price\n"))#this is type casting
# print("Hello"," ",a)
# print(type(a))


#only addition calculator

a = int(input("please enter number 1\n"))
b = int(input("please enter number 2\n"))
c = a+b
print(c)


# #assignments
# 1.take the inputs for the user for fournumber then add them(10+20+30+40)
# 2.1.take the inputs for the user for greet the user(good morning rajesh)
# 3.price calculation for 3 groceries need to take the input from the user (12.34+45.89+78.10)


# myname = int(input("enter your name"))
# print(myname)

# myname = str(input("enter your name"))
# print(myname)

# myname = float(input("enter your name"))
# print(myname)


# mynum = int(input("enter your num"))
# print(mynum)





