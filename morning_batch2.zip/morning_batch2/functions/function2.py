#input function 
def greeting(name):#Zero arguments based function
    """
    This function will greet the person
    """
    print("Good morning "+name)  
 
    
a = input("enter your name")
greeting(a) 
greeting(a) 
greeting(a) 
print("this is yet another test")
greeting(a) 
greeting(a) 
greeting(a) 

