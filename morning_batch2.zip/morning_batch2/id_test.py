# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 08:06:28 2022

@author: durga
"""

# =============================================================================
# address or id
# =============================================================================
venkata_bhasker = 20
manoj =20

print(venkata_bhasker) 
print("manoj===",manoj)


#id  is used to check for address
#inbuilt---id
syntax:
    id(variable_name)
    return ----->address of the variable

print(id(venkata_bhasker))
print("manoj id",id(manoj))
print("=========================")
manoj = 30
#print(manoj)
print(id(manoj))
print(id(venkata_bhasker))